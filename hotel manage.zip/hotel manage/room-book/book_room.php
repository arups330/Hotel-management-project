
<?php
session_start();
if(isset($_POST['book_room'])){

              $connection=mysqli_connect("localhost","root","");
              $db = mysqli_select_db($connection,"hotel");
              if($_POST['room_type']== 'Single Non-AC'){
                  $query="update singlenonac set holder_name='$_POST[holder_name]',
                  holder_id=$_POST[holder_id],holder_add='$_POST[holder_address]',holder_mobile='$_POST[holder_mobile]',
                  in_date='$_POST[in_date]',out_date='$_POST[out_date]', status=1 where rno=$_POST[room_no]";
              }
              if($_POST['room_type']== 'Single AC'){
                $query="update singleac set holder_name='$_POST[holder_name]',
                holder_id=$_POST[holder_id],holder_add='$_POST[holder_address]',holder_mobile='$_POST[holder_mobile]',
                in_date='$_POST[in_date]',out_date='$_POST[out_date]', status=1 where rno=$_POST[room_no]";
            }
            if($_POST['room_type']== 'Double Non-AC'){
                $query="update doublenonac set holder_name='$_POST[holder_name]',
                holder_id=$_POST[holder_id],holder_add='$_POST[holder_address]',holder_mobile='$_POST[holder_mobile]',
                in_date='$_POST[in_date]',out_date='$_POST[out_date]', status=1 where rno=$_POST[room_no]";
            }
            if($_POST['room_type']== 'Double AC'){
                $query="update doubleac set holder_name='$_POST[holder_name]',
                holder_id=$_POST[holder_id],holder_add='$_POST[holder_address]',holder_mobile='$_POST[holder_mobile]',
                in_date='$_POST[in_date]',out_date='$_POST[out_date]', status=1 where rno=$_POST[room_no]";
            }
              
              $query_run=mysqli_query($connection,$query);
              header("Location:redirect_page.php");
}

?>

<html>
    <head>
        <meta charset="utf-8">
        <title>Royal Palace</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="main.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/dbed6b6114.js" crossorigin="anonymous"></script>
        <link rel = "icon" href = "images/logo.png" type = "image/png">
    </head>
    <body>
        
        <!-- header -->
        <header class = "header" id = "header">
            <div class = "head-top">
                <div class = "site-name">
                    <span><img id="siz" src=images/royal.png alt="Royal Hotel" hight=10 width=20></span>
                </div>
                <div class = "site-nav">
                    <span id = "nav-btn">MENU <i class = "fas fa-bars"></i></span>
                </div>
                
            </div>

            
        </header>
        <!-- end of header -->
         <!-- side navbar -->
         <div class = "sidenav" id = "sidenav">
            <span class = "cancel-btn" id = "cancel-btn">
                <i class = "fas fa-times"></i>
            </span>

            <ul class = "navbar">
                <li><a href = "#header">home</a></li>
                <li><a href = "#services">services</a></li>
                <li><a href = "#rooms">rooms</a></li>
                <li><a href = "#customers">customers</a></li>
                <li><a href = "signupsignin.html">Sign in/ Sign Up</a></li>
            </ul>
            
        </div>
        <!-- end of side navbar -->
        <br><br>
        <div class="row">
            <div class="col-md-12">
                <center><h2> Room Booking page </h2></center>
            </div>
        </div>  
        <div class="row"  >
            <div class="col-md-4"></div>
                <form  action="" method="post">
                    


                    <div class="form-group">
                        <label>Room No:</label>
                        <input type="text" class="form-control" name="room_no" required=""
                        value="<?php echo $_GET['rn'];    ?>">
                    </div>

                    <div class="form-group">
                        <label>Room Type:</label>
                        <input type="text" class="form-control" name="room_type" required=""
                        value="<?php if($_GET['rt']=='a'){echo 'Single Non-AC';} 
                        if($_GET['rt']=='b'){echo 'Single AC';}
                        if($_GET['rt']=='c'){echo 'Double Non-AC';}
                        if($_GET['rt']=='d'){echo 'Double AC';}   ?>">
                    </div>
                    <div class="form-group">
                        <label>Holder Name:</label>
                        <input type="text" class="form-control" name="holder_name" required="">
                    </div>
                    <div class="form-group">
                        <label>Holder Id:</label>
                        <input placeholder="Decimal Number Only" type="text" class="form-control" name="holder_id" required="">
                    </div>
                    <div class="form-group">
                        <label>Holder Mobile:</label>
                        <input type="text" class="form-control" name="holder_mobile" required="">
                    </div>
                    <div class="form-group">
                        <label>Holder Address:</label>
                        <textarea rows="3" cols="40" class="form-control"name="holder_address" required=""></textarea>
                    </div> 
                    <div class="form-group">
                        <label>Check In Date:</label>
                        <input placeholder="Year-Month-Date"type="text" class="form-control" name="in_date" required="">
                    </div>
                    <div class="form-group">
                        <label>Check Out Date:</label>
                        <input placeholder="Year-Month-Date" type="text" class="form-control" name="out_date" required="">
                    </div>
                    <button type="submit" style="margin-left:5em"class="btn btn-warning" name="book_room">Book Now</button>
               </form>   
            </div> 
            <div class="col-md-2"></div>
    
        </div>
                    
        
 <!-- footer -->
        <footer class = "footer">
            <div class = "footer-container">
                <div>
                    <h2>About Us </h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque sapiente mollitia doloribus provident? Eos quisquam aliquid vel dolorum, impedit culpa.</p>
                    <ul class = "social-icons">
                        <li class = "flex">
                            <i class = "fa fa-twitter fa-2x"></i>
                        </li>
                        <li class = "flex">
                            <i class = "fa fa-facebook fa-2x"></i>
                        </li>
                        <li class = "flex">
                            <i class = "fa fa-instagram fa-2x"></i>
                        </li>
                    </ul>
                </div>

                <div>
                    <h2>Useful Links</h2>
                    <a href = "#">Blog</a>
                    <a href = "#">Rooms</a>
                    <a href = "#">Subscription</a>
                    <a href = "#">Gift Card</a>
                </div>

                <div>
                    <h2>Privacy</h2>
                    <a href = "#">Career</a>
                    <a href = "#">About Us</a>
                    <a href = "#">Contact Us</a>
                    <a href = "#">Services</a>
                </div>

                <div>
                    <h2>Have A Question</h2>
                    <div class = "contact-item">
                        <span>
                            <i class = "fas fa-map-marker-alt"></i>
                        </span>
                        <span>
                            203 Fake St.Mountain View, San Francisco, California, USA
                        </span>
                    </div>
                    <div class = "contact-item">
                        <span>
                            <i class = "fas fa-phone-alt"></i>
                        </span>
                        <span>
                            +84545 37534 48
                        </span>
                    </div>
                    <div class = "contact-item">
                        <span>
                            <i class = "fas fa-envelope"></i>
                        </span>
                        <span>
                            info@domain.com
                        </span>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end of footer -->
        
        <script src="script.js"></script>
    </body>
</html>